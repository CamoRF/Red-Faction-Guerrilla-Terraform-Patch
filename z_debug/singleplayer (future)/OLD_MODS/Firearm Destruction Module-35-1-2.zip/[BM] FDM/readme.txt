BetterMARS Firearm Destruction Module - 1.2
Makes weapons pack a punch! Weapons will now suppress and cause damage to structures.

:: REQUIREMENTS::
� Mod Manager 1.01 (Stock mods may need structure changed to match Re-MARS-tered

:: FEATURES::
� Most firearms will cause structural damage
� Certain turrets will cause structural damage
� Balanced to enhance gameplay without going overboard

:: OPTIMIZATION ::
Firearm Destruction is accomplished with invisible "explosions"
with values tuned to match what would be as realistic as possible.

There's a hardcoded limitation to how many ongoing explosions can occur at once. 
When this limit is reached, explosions will get added to a buffer or queue until the last one is complete.
To reduce the chance of the buffer being reached, the following firearms do not produce destruction:
EDF Pistol
EDF Enforcer
Various auto turrets

If you encounter problems or frequently hit the buffer, please provide feedback.