How to install:
1) Download and install the mod manager for RFG Re-mars-tered. Mod manager is used to decrease the chance of issues when multiple mods are used and to make mods easy to install. Once installed, ModManager.exe file should be in the same folder as rfg.exe.
2) Unzip this mod into the mods folder in your RFG Re-mars-tered directory.
3) Run ModManager.exe.
4) Enable 'No FFZ Artillery', and click 'Activate mods'. If there are no issues, close modmanager and run RFG re-mars-tered via steam. If you try to run the game from modmanager you'll get an error. You must launch it from steam.
5) Drive happily into the FFZ & EOS