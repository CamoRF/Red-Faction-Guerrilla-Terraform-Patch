How to install:
1) Download and install the mod manager for RFG Re-mars-tered. Mod manager is used to decrease the chance of issues when multiple mods are used and to make mods easy to install. Once installed, ModManager.exe file should be in the same folder as rfg.exe.
2) Unzip this mod into the mods folder in your RFG Re-mars-tered directory.
3) Run ModManager.exe.
4) Enable 'Use artillery anywhere', pick your settings, and click 'Activate mods'. If there are no issues, close modmanager and run RFG re-mars-tered via steam. If you try to run the game from modmanager you'll get an error. You must launch it from steam.

How to use:
1) Start a new game.
2) Kill Dan. I enabled movement from the start so you don't have to wait for him to stop talking first.
3) The satellite view should start. Wait for it to stop moving (takes ~2 minutes). Once it's done moving you can freely move around the whole map and fire the artillery gun. Have fun!

Notes:
- You can usually move more quickly by using the WASD buttons while moving your mouse in that direction.
- Sometimes you won't see the explosion effect. I'm looking into how to fix that.
- To zoom out, try and find a mountain or hill and move up it. The camera height is based off the height of the ground beneath it. Alternatively set the zoom setting a bit higher in the mod manager.
- Let me know if you run into any issues and I'll do my best to fix them. 

Feedback / Issues:
The best way to contact me is on the red faction discord: https://discord.gg/Y5TskX or pm me @moneyl#5720 on discord. Alternatively, make a comment on the nexus page for this mod, however, I won't check that as often.