	[[ INDEX ]]

[[ 1. Introduction ]]
[[ 2. Installation ]]
[[ 3. Feature List ]]
[[ 4. Guide ]]
[[ 5. Known Issues ]]
[[ 6. Mod Compatibility ]]
[[ 7. Credits ]]
[[ 8. Ethical Faction Notes ]]



	[[ 1. Introduction ]]

Fellow dissidents and terrorists,

When we first gazed in awe upon Red Faction: Guerrilla, we had found a treasure soon to be lost in obscurity. Now, in 2021, RFG is still the best demolition game out there and per extension one of the most replayable open-world games to date. On top of that, we have a re-mastered version!

So without further ado I give you the best of old RFG mods combined and re-overhauled in a single customizable pack, the most ambitious to date, with emphasis on realism and balance. Settings are included to tailor your experience using the Mod Manager included in the download.

As this mod fixes various vanilla bugs and greatly improves many of its aspects I recommend installing it even on your first playthrough. There's also a New Game+ version, recommended for repeat playthroughs, which unlocks all upgrades and causes endgame enemies/allies to spawn from the start.

Questions, feedback? The most reliable way to contact me is through the Red Faction discord: https://discord.gg/redfaction



	[[ 2. Installation ]]

To install:

1. Download the latest "RFG 2021 Community Pack (x.x).zip" from FactionFiles or Nexusmods.
2. Extract the contents of the archive directly to your RFG game folder, which may vary:
	A) Steam: \\SteamLibrary\SteamApps\common\Red Faction Guerrilla Re-MARS-tered
	B) GOG: C:\Program Files (x86)\GOG Galaxy\Red Faction Guerrilla Re-Mars-tered
	C) ...or whatever location you chose during installation. An easy way to check is to use the game's shortcut on your desktop (rightclick, Properties) and check its target directory.
3. Open "Mod Manager Re-mars-tered" inside the game folder.
4. Ensure the Game Folder is correctly selected in the Mod Manager.
5. Check the box next to -2021 Community Pack- or -2021 Community Pack NG+- (not both).
6. Click Activate Mods.

That's it, the installation is complete! You can either start the game normally or using the "Run game" button in the Mod Manager.

Optional: 
 - Keybinds tip: Change Melee to "F", Zoom to "right mouse button", Crouch to "left-Control", Activate Backpack to "X" and Detonate Charges to "C". Turning off camera shake is also strongly recommended.
 - You can switch between the normal and NG+ versions freely, though keep in mind that NG+ mode unlocks and automatically purchases all upgrades except the Nano Forge, which must be purchased manually at the upgrade bench. If the game is saved after, you can't get rid of the upgrades in that save.



	[[ 3. Feature List ]]

In short: Finely balanced overhaul to difficulty, weapons, backpacks, explosions, demolition, vehicles, upgrades, missions, activities, stealth, AI, alerts, graphics and more, including bugfixes and New Game+. Have fun!

In detail, this modpack changes the following, both for the base game and the DLC bonus mission:
{ = CONFIGURABLE IN MOD MANAGER

{1. Radically improved demolition.
   A) Explosions are smaller but more powerful. Environmental explosives, particularly various gas containers, deal less structure damage and no longer fling debris across the map, but a weapon has been added to do just that.
   B) The Sledgehammer is weaker until fully upgraded, but due to the physics changes and its precision it'll let you take down buildings in a highly satisfying manner. You'll learn far more about how each building is constructed, as now it actually matters.
   C) Stress damage takes advantage of modern hardware and has been tweaked for realism, resulting in more believable destruction.
   D) The player has more time for demolition as combat is faster and more decisive. Enemy reinforcements take more time to arrive.
{2. Redesigned Alert levels. How quickly the alert dies down depends largely on how far you are from your last hostile action, encouraging hit-and-run tactics. When you do assault the enemy head on, expect the alert level to rise quickly. EthicalLune's settings are also included in case you want to remain in alert, which can be fun on lower difficulties.
{3. Option to change Hard difficulty to Insane settings, instead of having to complete the game to unlock Insane mode.
{4. Optionally bring a squad of allied guerrillas, which is useful since they'll man your vehicle's turret. WARNING: Bugs House Arrest activity when active, causing hostages to die when released. Leave at the default "disable" option for these.
 5. Completely overhauled all weapons for balance; underpowered weapons repurposed. Bullets are plentiful and ammo crates replenish more explosives. Large caliber weapons damage structure and deal more vehicle damage (though less than vanilla). See "Guide" below for details.
 6. Better vehicle physics and attributes:
   A) Handling and control vastly improved. Less cartoony driving and collisions, small civilian cars are less durable and tanks more durable. Light vehicles are notably less bouncy due to improved suspension.
   B) Heavy vehicles now feel much heavier compared to light vehicles, handle very differently and can be used to smash through buildings while light vehicles will barely dent them. Keep in mind that Mars has 38% of Earth's gravity, hence vehicles still feel lighter than in real life.
   C) Improved realism: NPCs now have the same acceleration and ramming power as the player when using a vehicle, and artificial gravity has been removed from most vehicles.
   D) Bullets deal less damage to vehicles. EDF vehicles and some heavy civilian vehicles, including walkers, provide armor against bullets; the Fuel Tanker on the other hand takes more bullet damage due to its volatile cargo.
   E) Fixed Jenkins' Jetter randomly bugging out, vastly improved its handling and fixed a few other vehicle-related bugs such as the "invisible object collision".
 7. Re-balanced unlock requirements and upgrade costs based on usefulness. Comfort upgrades like safehouse warping and the Jetpack unlock much earlier.
 8. Improved graphics. Depth-of-field added to normal camera to blur distant terrain, larger decal/blood spatter ranges and angles, bigger muzzle flashes, less ridiculous vehicle explosions, theme-appropriate explosion effects for each weapon, cartoony backpack effects removed and more.
 9. Stealth overhauled to actually be useful, especially on higher difficulties. More on stealth under "Guide".
 10. Mars is more populated and lively, including larger vehicle variety.
 11. Salvage (cash) is only earned through demolition and activities (not missions or morale).
 12. Morale is more dynamic, changing quickly depending on how successful you are. Dying lowers morale, killing enemies and wrecking enemy buildings/aircraft/tanks raises morale.
 13. Rebalanced difficulty and combat settings, intended to be realistic at higher difficulties and fun on lower difficulties: 
   A) Both you and NPCs die faster making alertness and timing more important, and combat far more satisfying.
   B) Difficulty no longer affects meta dynamics (ammo, morale etc) nor damage dealt to enemies.
   C) Up to 50% more enemies shoot at you at the same time. Being surrounded is worse and positioning more important.
   D) NPC perception made more realistic by changing vision cone angle and distance. Especially unaware NPCs are less perceptive, while alerted enemies spot you as easily as you spot them.
   E) Red Faction allies are now weaker than EDF troops, but more numerous than in vanilla.
   F) Enemies take cover often and more intelligently attempt to surround the player.
   G) Melee instantly kills an enemy, a powerful stealth tool, but is also dangerous to the player.
   H) A "what you see is what you get" approach to damage, both for the player and NPCs. No more hidden, unrealistic reductions. This also means NPCs deal full damage to each other in all situations, including off-screen.
 14. All Activities (side missions) overhauled for the new game balance, with realistic yet challenging pro times. Defense and Raids are more dramatic with more forces on both sides. Demolition Master is designed to challenge your understanding of structural integrity and efficiency. Transporter is a bit easier as racing, though liked by some, is despised by many gamers. The Riding Shotgun machine gun turret is now an anti-armor cannon, used alongside the main RPG turret, and the camera is much closer so that you can immersively enjoy the mayhem. Jenkins' Jetter, along with the handling improvements, is also more durable and slower.
 15. Various Missions have been altered based on the new difficulty, to soften difficulty spikes.
 16. Backpacks overhauled - the awful ones are now useful, heavy ones slow you down, function as armor and Stealth is less overpowered. They unlock gradually early on with returning players in mind. Purchase costs balanced based on their usefulness. Check "Guide" below for details.
 17. Reconstructor added to singleplayer upgrades.
 18. Fall damage made more dependent on armor upgrades. At the last upgrade level, only extreme fall speeds will kill you.
 19. Wrecking Crew with High Building Collapse redesigned for mesmerizing visual drama. Also available in the Mod Manager as an option for regular singleplayer ("story mode").
 20. A new bonus weapon is unlocked after finishing the game, the thrown explosive Ostrich, intended purely for hilarity. See "Guide" below.
 21. Handy info for modders in a separate text file.

...and many other subtle improvements.



	[[ 4. Guide ]]

Start a New Game to fully experience this pack! It's not 100% savegame compatible but won't break the game if you try anyway; you'll merely miss out on a few upgrade changes.


	Weapons:
 - Sledgehammer: Strong against infantry and structure. Increases run speed when active.
 - Remote Charges: Small radius, but powerful enough to destroy any structure component in a single blast - the expert demolitionist's choice. Also increases run speed, has a high ammo count and ammo caches fully restock them. Good against vehicles if you manage to hit them.
 - Arc Welder: Now the "Plasma Caster", a weapon which hurls a destructive charge over a declining trajectory. Excels at destroying weak structure and blasting away the debris as shrapnel, which destroys a building's internal walls or other buildings nearby. Can send vehicles flying but deals moderate damage to them. Also added to the DLC!
 - RPG Launcher: Still an RPG Launcher, though it fires salvos of small rockets which fly up, then slam down on top of the target, causing a small yet powerful anti-armor explosion. Powerful against vehicles but lacks crowd control. Warranty void if used indoors.
 - Pistol: An infiltration tool. Competent in mid-range combat and it kills in a single headshot; powerful if your aim is good. More importantly it's relatively silent (20m sound range) and increases run speed.
 - Shotgun: Now sprays a huge amount of pellets across a wide area, destroys cover easily, causes enemies to flinch but is much slower.
 - Grinder: Ricochets wildly, holds more ammo and when fully upgraded can be used against infantry, vehicles and buildings alike. However, it's optimal against none and has a hard-to-use charge trigger.
 - Nano Rifle: A silent marksman's rifle which dissolves corpses. Kills instantly on a headshot, deals moderate damage to vehicles and buildings. Excellent if combined with the Stealth backpack, ideal for downing flyers and overall one of the best weapons, its only downside being the price tag.
 - Sniper Rifle: Destroys structure with ease and has far greater zoom. Notable because the stealth improvements allow this weapon to clear outposts without raising the alarm, despite being loud.
 - Gauss Rifle: A burst fire, crowd control weapon powerful against unarmored vehicles but usable against all targets - notably mediocre against shielded infantry and armored vehicles.
 - Rail Driver: Punches a gaping hole through everything in a straight line, including buildings! Powerful, but low max ammo.
 - (DLC)Spiker: Used as Samanaya's main stealth weapon, the Spiker is now a semi-automatic marksman rifle.
 - Golden Sledgehammer: Unlocked after completing the game - a direct upgrade over the Sledge with even better movement speed and higher structure/vehicle damage.
 - Ostrich: The pinnacle of guerrilla weapons technology, unlocked after completing the game. Dual-wield two ostriches which can be thrown as weapons of mass destruction. Increases movement speed radically. Best used on Casual with the Jetpack and demolition reset.

Other weapons not listed here are now useful in their own way, contrary to the base game. Try them all!


	Backpacks:
These were added to singleplayer in the remaster. In the Community Pack they'll unlock gradually by completing activities. Note that Rhino and Tremor can make Demolitions Master activities easy as I intentionally didn't make their use a requirement to get "pro times". Most can now be deactivated with a second button press and used with partial fuel.

 - Thrust: Can be used freely and almost eliminates fall damage when equipped. Useful to attack from above, explore mountains or destroy buildings by blasting through the roof. Also allows you to slam the ground by holding the jump key during activation.
 - Fleetfoot: When active lowers reload time by 40%, increases fire rate by 20%, allows you to run very rapidly and no longer disables fine aim nor zooms out the camera. Perfect for hit-and-run attacks.
 - Rhino: Passively decreases damage taken by 40%, slows movement and reload speed by 25%. But, the Rhino's sluggish appearance can be deceiving - activate to charge rapidly, plowing through anything that stands in your way with added zoom-out to better enjoy the destruction. Perhaps its most interesting feature is flipping tanks over, which kills the driver and allows you to take it for yourself.
 - Concussion: Radius increased, structure damage removed and can be used more often. Powerful against infantry and quite fun, but equally dangerous to your allies. Still less useful than other backpacks but cheap to compensate.
 - Tremor: Heavy like the Rhino, passively reduces damage by 20% and slows movement by 10%. When active slows movement speed and grants 65% damage reduction, causing a small yet powerful earthquake around the player with a large flinch radius. Allows you to demolish buildings while engaging enemies and frees up weapon slots, so you finally have a good reason to bring Proximity Mines or a shotgun.
 - Firepower: While active decreases damage taken by 20%, increases melee power (using a mini-explosion which no longer looks ridiculous), increases projectile damage by 25% just like vanilla but no longer increases explosives damage, and lasts longer. Passively increases ammo and magazine capacity by 25% - its main attraction.
 - Heal: Now actively heals over a longer period (4s instead of 1s), but with a 70% damage reduction making it more useful in battle. Passively increases health regen a flat amount, which is barely noticeable on lower difficulties but significant on Hard/Insane. Also no longer looks ridiculous.
 - Vision: Can now be used much longer (20s instead of 8s) to see enemies behind objects. When active increases projectile weapon damage by 35%. Useful for ambushes and flanking, killing enemies before they can retaliate.
 - Stealth: No longer game-breakingly overpowered, but still the best backpack on higher difficulties. Enemies will ignore you earlier after activation (0.2s instead of 1s) but active time has been sharply reduced (13.3s to 7.6s).
 - Jetpack: Same old jetpack, but with a 15% movement boost, longer flight time and minor fall damage reduction - the ultimate mobility enhancer. Unlike Thrust, you'll need to slow long falls to avoid taking damage. Unlocks much earlier.


	Stealth:
Stealth was always in the game but not viable. Thanks to the Stealth backpack and my tweaks it now is, especially with the Pistol, Nano or Sniper.

Take hostile actions only when no enemies have line of sight to you; they turn around rapidly. Don't get spotted, or kill the alarmed soldiers before the alert is raised. Bullets flying past enemies will immediately reveal you, after which you have a few seconds to kill them to avoid an alert.

The Nano Rifle is the best stealth weapon because it disintegrates corpses, though it isn't required. When a corpse is found, enemies become much more perceptive but they won't sound the alarm unless you're spotted personally.

Understanding stealth will allow you to play on higher difficulties far more easily.


	Alerts:
Alerts are more dangerous and ramp up more quickly, but when you put some distance between yourself and your last hostile action the enemy will quickly lose track of you. Now it takes skill and tactical thinking to stay alive.

Alternatively, use EthicalLune's alert decay settings if you want the EDF to chase you down no matter where you go, forcing you to either play on low difficulty or retreat to a hideout after a strike.


	Difficulty modes:
 - Casual is highly entertaining, swatting enemies like flies while you rambo into red alert with impunity.
 - Normal becomes the actual normal difficulty, recommended for regular gamers. 
 - Hard is hard, for those who like a challenge. Near-realistic.
 - Insane is insane, intended for immersive role playing and realism though not recommended for most players. This is the only mode in which you can be killed in a single shot! I've completed the game on this mode to ensure it's doable, even if punishing.



	[[ 5. Known Issues ]]

Just one caused by this overhaul:
 - As mentioned, the player squad causes House Arrest hostages to die when freed, if active. Simply turn it off to solve the problem (you can retry these activities).

Besides that I've fixed all problems encountered during extensive play-testing, including a few present in the vanilla game. Some vanilla problems still exist:
 - Overacceleration still happens at times, though less than in vanilla.
 - The remaster-added option to reset destruction after finishing the game sometimes bugs buildings, making them almost invulnerable. Easily solved by warping to any hideout.
 - Backpacks are sometimes unlocked at game start. You could try starting a new game until it works properly or just ignore the issue - you still have to pay the salvage cost anyway.
 - Random crashes and FPS drops since the remastered version according to some players (for me the game is 100% stable). It's unlikely to be patched but some crashes/drops are fixed by playing "fullscreen windowed" (not exclusive fullscreen) and basic software maintenance (updating drivers, repairing microsoft frameworks, verifying game files etc). Use Google/DuckDuckGo for more info.

A few things I wanted to include but couldn't:
 - The Bulldozer causes crashes so I couldn't add it to the game.
 - Too many guerrillas will block doorways so I can't spawn as many as I'd have liked.
 - Unlocking Insane mode from the start doesn't seem possible using the XML files. Workaround included.
 - The DLC remote charges were causing crashes, so I changed them to the default remote charges.
 - Adding the Spiker and Subverter DLC weapons to the base game. It's possible using an installer, but I'm not sure how to do it with the ModManager.



	[[ 6. Mod Compatibility ]]

This modpack overwrites many of the game's files when activated, and must be activated first to avoid un-doing the effects of other mods, hence the " - " added to the name in the modmanager.

To find out whether another mod will overwrite the modpack's files, check its "modinfo.xml" and see if there are <Replace> lines anywhere. Remove conflicts by choosing which mod gets to replace which file. If it's a clean mod (unlike this pack) there won't be any <Replace> lines.

If you accidentally activate both versions of the Community Pack at the same time, no worries; you'll simply be in NG+ mode.



	[[ 7. Credits ]]

[] EthicalLune's Ethical Faction - The most ambitious overhaul mod before this one, and rightly the most downloaded on the Nexus. Quite a few of his changes are part of this modpack, tweaked and balanced, though perhaps more importantly he dove through the game files and demonstrated a wide variety of possibilities; a pioneer.
[] Sturm-Falke101 - Both for the squad mod and his guides on modding RFG. Excellent work.
[] Jakkar's Realism - The best physics mod back in the day, which is why his stress settings are optionally included.
[] Moneyl for his many contributions to RFG modding and fixing the "run game" button for the GOG version.
[] The tool-makers who made modding RFG easy: Gibbed, HazardX, Moneyl and Brian Wychopen. Huge thanks!
[] Volition for making such a brilliant game, and THQ Nordic for the remaster.
[] Myself of course for combining the best mods, exhaustively re-balancing and testing the result, overhauling other aspects of the game, updating everything for the remaster, adding all changes to the DLC, New Game+ and writing this readme. Plus, taking far too long to publish... All in all, hundreds of hours went into this project so I hope you enjoy the result.



	[[ 8. Ethical Faction Notes ]]

Taken from EthicalLune's Readme, but with removed content cut out:

*==New and/or radically changed items==*
-The Rocket Launcher has been turned into a bad-ass missilepod which unleashes a barrage of minimissiles, which fly up into the air and then slams down into the target
-The Arc Welder has been transformed into a Plasma Caster (functionally sorta replacing the vanilla rocket launcher, but requires a bit more skill to use)
-The Sniper Rifle has been upgraded to fire a shockwave round which punches a hole in most structures and can knock enemies down when hit

*==Gonnes and such==*
-All guns have received extra visual effects, such as bigger muzzleflashes and more prominent barrelsmoke for all EDF related guns
-Shotguns and the Sniper Rifle deals environmental damage, aka stuff breaks if you shoot it with these guns
-Most guns reload with NPC animations rather than Player animations
-Weapons impact movement speed a lot more
-Melee with regular weapons very little structure damage
-Melee applies less force to ragdolls
-You can carry more boolits for most gonnes
-Various turrets have 50% longer cooldowns
-The Rail Driver has a 5~ second cooldown between shots, does massive damage capable of killing a normal elite instantly, and damages structures (also reduced max ammo)
This is the only weapon that can kill enemies inside tanks and the like, pick your shots carefully!
-The Gutter has a strong +35% movement speed bonus
-The Gutter is very deadly... Against you as well! Keep your distance.

*==Gameplay==*
-NPC's killing eachother will not affect morale anymore, it only matters if you kill an ally
-NPC's will generally run to cover and hide indoors more than before
-NPC's in general have more aggressive firing patterns with most things
-Guerrilla reinforcements have a little bit lower morale requirements (basic reinforcements happen at morale 20, then better ones at 30, 40, 50, 60, 70, 80 and 95)
-All territories have increased control, making them harder to take over

*==Vehicles==*
-You can stand on top of moving vehicles better, but not perfectly

*==Other stuffs==*
-Heavies have a lot more health
-More NPC's spawn