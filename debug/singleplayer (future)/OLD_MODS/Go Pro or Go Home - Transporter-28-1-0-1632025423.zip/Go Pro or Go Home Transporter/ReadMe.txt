Unzip.

Move mod folder into Mod Manager's mod folder.

Start Mod Manager.

Click check box for mod.

Click "Active Mods."

Click "Run Game."

Profit?